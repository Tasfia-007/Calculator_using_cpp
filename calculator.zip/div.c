#include "calculator.h"

double(int a, int b){
    return ((double)a/b);
}