#include<stdio.h>
#include<stdlib.h>
#include "calculator.h"
int main()
{
    int a,b,y;
    char c;
    printf("Enter two numbers a and b: ");
    scanf("%d%d",&a,&b);
    printf("Enter the operation youwant to choose\nfor sum type 1\nfor substraction type 2\nfor multitplication type 3\n for division type 4\n");
    scanf("%c",&c);
    switch(x)
    {
        case 1:
        y=add(a,b);
        printf("%d + %d = %d ",a,b,y);
        break;
         case 2:
        y=sub(a,b);
        printf("%d - %d = %d ",a,b,y);
        break; 
        case 3:
        y=mmulti(a,b);
        printf("%d x %d = %d ",a,b,y);
        break;
        case 4:
        y=add(a,b);
        printf("%d / %d = %d ",a,b,y);
        break;
    } return 0;
}