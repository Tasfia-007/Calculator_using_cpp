#include "calculator.h"

int add(int a, b){
    return a+b;
}